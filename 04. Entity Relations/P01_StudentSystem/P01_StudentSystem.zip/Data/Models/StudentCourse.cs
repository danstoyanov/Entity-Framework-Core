﻿namespace P01_StudentSystem.Data.Models
{
    public class StudentCourse
    {

    }
}
