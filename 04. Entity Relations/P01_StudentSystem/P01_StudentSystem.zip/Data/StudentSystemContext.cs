﻿namespace P01_StudentSystem.Data
{
    public class StudentSystemContext
    {

    }
}
