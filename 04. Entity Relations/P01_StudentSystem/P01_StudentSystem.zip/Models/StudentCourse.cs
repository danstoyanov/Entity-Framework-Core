﻿namespace P01_StudentSystem.Models
{
    public class StudentCourse
    {

    }
}
