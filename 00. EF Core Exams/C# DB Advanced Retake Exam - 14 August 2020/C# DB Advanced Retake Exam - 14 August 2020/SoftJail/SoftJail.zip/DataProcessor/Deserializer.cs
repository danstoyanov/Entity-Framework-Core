﻿namespace SoftJail.DataProcessor
{

    using Data;
    using Newtonsoft.Json;
    using SoftJail.Data.Models;
    using SoftJail.DataProcessor.ImportDto;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;

    public class Deserializer
    {
        public const string ErrorMessageInvalid = "Invalid Data";
        public const string SuccessfullyAddedDepartment = "Imported {0} with {1} cells";


        public static string ImportDepartmentsCells(SoftJailDbContext context, string jsonString)
        {
            var result = new StringBuilder();

            var jsonDepartments = JsonConvert.DeserializeObject<IEnumerable<JsonDepartmentModel>>(jsonString);

            var departments = new List<Department>();

            foreach (var jsonDepartment in jsonDepartments)
            {
                if (!IsValid(jsonDepartment) || jsonDepartment.Cells.Any(c => c.CellNumber == 0))
                {
                    result.AppendLine(ErrorMessageInvalid);
                    continue;
                }

                var department = new Department()
                {
                    Name = jsonDepartment.Name,
                };

                foreach (var jsonCell in jsonDepartment.Cells)
                {
                    if (!IsValid(jsonCell))
                    {
                        result.AppendLine(ErrorMessageInvalid);
                        continue;
                    }

                    var cell = new Cell()
                    {
                        CellNumber = jsonCell.CellNumber,
                        HasWindow = jsonCell.HasWindow,
                    };

                    department.Cells.Add(cell);
                }

                departments.Add(department);
                result.AppendLine(string.Format(SuccessfullyAddedDepartment, department.Name, department.Cells.Count));
            }

            context.Departments.AddRange(departments);
            context.SaveChanges();

            return result.ToString().TrimEnd();
        }


        public static string ImportPrisonersMails(SoftJailDbContext context, string jsonString)
        {
            throw new NotImplementedException();
        }

        public static string ImportOfficersPrisoners(SoftJailDbContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);
            return isValid;
        }
    }
}