﻿using System;

namespace _02._Database_First
{
    public class StartUp
    {
        static void Main()
        {

        }
    }
}
